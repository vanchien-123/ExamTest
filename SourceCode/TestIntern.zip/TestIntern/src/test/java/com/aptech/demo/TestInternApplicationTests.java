package com.aptech.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestInternApplicationTests {

	@Test
	void contextLoads() {
	}

}
